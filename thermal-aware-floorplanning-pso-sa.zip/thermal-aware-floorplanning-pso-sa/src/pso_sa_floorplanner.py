import json
import math
import random
import numpy as np
from thermal_model import ThermalGridModel

class HybridPSOSA_Floorplanner:
    def __init__(self, config_path):
        with open(config_path, 'r') as f:
            self.config = json.load(f)
        self.modules = self.config["modules"]
        self.weights = self.config["weights"]
        self.thermal_model = ThermalGridModel()
        
    def calculate_cost(self, placement):
        """Computes weighted multi-objective cost: Area, Wirelength, Peak Temp."""
        # Compute bounding box (Area)
        max_x = max(placement[m["name"]][0] + m["width"] for m in self.modules)
        max_y = max(placement[m["name"]][1] + m["height"] for m in self.modules)
        area = max_x * max_y

        # Compute Wirelength (Half-Perimeter Wire Length - HPWL approximation)
        wirelength = 0.0
        centers = {}
        for m in self.modules:
            name = m["name"]
            x, y = placement[name]
            centers[name] = (x + m["width"]/2.0, y + m["height"]/2.0)
        
        names = list(centers.keys())
        for i in range(len(names)):
            for j in range(i+1, len(names)):
                c1, c2 = centers[names[i]], centers[names[j]]
                wirelength += abs(c1[0] - c2[0]) + abs(c1[1] - c2[1])

        # Overlap Penalty
        overlap_penalty = 0.0
        for i in range(len(self.modules)):
            m1 = self.modules[i]
            x1, y1 = placement[m1["name"]]
            for j in range(i+1, len(self.modules)):
                m2 = self.modules[j]
                x2, y2 = placement[m2["name"]]
                if not (x1 + m1["width"] <= x2 or x2 + m2["width"] <= x1 or
                        y1 + m1["height"] <= y2 or y2 + m2["height"] <= y1):
                    dx = max(0, min(x1 + m1["width"], x2 + m2["width"]) - max(x1, x2))
                    dy = max(0, min(y1 + m1["height"], y2 + m2["height"]) - max(y1, y2))
                    overlap_penalty += dx * dy * 500.0

        # Thermal estimation
        peak_temp, _ = self.thermal_model.compute_temperature_map(placement, (max_x, max_y), self.modules)

        total_cost = (self.weights["alpha_area"] * area +
                      self.weights["beta_wirelength"] * wirelength +
                      self.weights["gamma_temp"] * peak_temp +
                      overlap_penalty)
        return total_cost, area, wirelength, peak_temp

    def pso_global_search(self, num_particles=20, max_iter=30):
        """PSO Phase: Global space exploration."""
        print("[PSO] Starting Global Exploration Phase...")
        particles = []
        for _ in range(num_particles):
            pos = {}
            for m in self.modules:
                pos[m["name"]] = (random.uniform(0, 15), random.uniform(0, 15))
            cost, _, _, _ = self.calculate_cost(pos)
            particles.append({"pos": pos, "best_pos": pos, "best_cost": cost})

        gbest = min(particles, key=lambda p: p["best_cost"])
        
        for iteration in range(max_iter):
            for p in particles:
                new_pos = {}
                for m in self.modules:
                    name = m["name"]
                    # PSO position update velocity heuristic
                    curr = p["pos"][name]
                    p_b = p["best_pos"][name]
                    g_b = gbest["pos"][name]
                    
                    nx = max(0, curr[0] + 0.5*(p_b[0] - curr[0]) + 0.5*(g_b[0] - curr[0]) + random.uniform(-1, 1))
                    ny = max(0, curr[1] + 0.5*(p_b[1] - curr[1]) + 0.5*(g_b[1] - curr[1]) + random.uniform(-1, 1))
                    new_pos[name] = (nx, ny)

                cost, _, _, _ = self.calculate_cost(new_pos)
                p["pos"] = new_pos
                if cost < p["best_cost"]:
                    p["best_cost"] = cost
                    p["best_pos"] = new_pos

            gbest = min(particles, key=lambda p: p["best_cost"])
            if (iteration + 1) % 10 == 0:
                print(f"  Iteration {iteration+1}/{max_iter} - Global Best Cost: {gbest['best_cost']:.2f}")

        return gbest["pos"]

    def sa_local_search(self, initial_placement, init_temp=100.0, cooling_rate=0.95, min_temp=1.0):
        """SA Phase: Local refinement & thermal hotspot reduction."""
        print("[SA] Starting Local Refinement & Hotspot Escaping Phase...")
        curr_pos = dict(initial_placement)
        curr_cost, _, _, _ = self.calculate_cost(curr_pos)
        best_pos = dict(curr_pos)
        best_cost = curr_cost

        T = init_temp
        step = 0
        while T > min_temp:
            step += 1
            # Perturb placement of a random high-power block
            candidate_pos = dict(curr_pos)
            target_mod = random.choice(self.modules)
            name = target_mod["name"]
            
            dx = random.uniform(-1.5, 1.5)
            dy = random.uniform(-1.5, 1.5)
            nx = max(0, candidate_pos[name][0] + dx)
            ny = max(0, candidate_pos[name][1] + dy)
            candidate_pos[name] = (nx, ny)

            cand_cost, _, _, _ = self.calculate_cost(candidate_pos)
            delta = cand_cost - curr_cost

            if delta < 0 or random.random() < math.exp(-delta / T):
                curr_pos = candidate_pos
                curr_cost = cand_cost
                if cand_cost < best_cost:
                    best_cost = cand_cost
                    best_pos = dict(candidate_pos)

            T *= cooling_rate

        print(f"[SA] Refinement Complete. Final Cost: {best_cost:.2f}")
        return best_pos

    def optimize(self):
        pso_placement = self.pso_global_search()
        final_placement = self.sa_local_search(pso_placement)
        cost, area, wl, peak_temp = self.calculate_cost(final_placement)
        print("\n=== Hybrid PSO-SA Optimization Summary ===")
        print(f"Total Area: {area:.2f} sq. units")
        print(f"Total Wirelength (HPWL): {wl:.2f} units")
        print(f"Estimated Peak Temperature: {peak_temp:.2f} K / °C")
        print(f"Final Optimized Cost: {cost:.2f}")
        return final_placement

if __name__ == "__main__":
    import sys
    cfg = sys.argv[2] if len(sys.argv) > 2 else "config/benchmark_modules.json"
    planner = HybridPSOSA_Floorplanner(cfg)
    planner.optimize()
