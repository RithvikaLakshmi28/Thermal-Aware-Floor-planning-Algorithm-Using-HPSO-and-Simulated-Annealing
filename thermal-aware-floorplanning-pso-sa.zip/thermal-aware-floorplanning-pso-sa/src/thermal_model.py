import numpy as np

class ThermalGridModel:
    """Grid-based steady-state thermal model for chip temperature estimation."""
    def __init__(self, grid_size=(32, 32), ambient_temp=300.0, thermal_resistance=0.8):
        self.grid_size = grid_size
        self.ambient_temp = ambient_temp
        self.r_th = thermal_resistance

    def compute_temperature_map(self, placement, chip_dim, modules):
        """
        Estimates thermal distribution across the chip grid.
        placement: dict of module_name -> (x, y)
        chip_dim: (width, height)
        """
        grid = np.zeros(self.grid_size)
        cw, ch = chip_dim
        gw, gh = self.grid_size

        if cw <= 0 or ch <= 0:
            return 1000.0, grid

        # Heat generation per grid cell
        for mod in modules:
            name = mod["name"]
            if name not in placement:
                continue
            x, y = placement[name]
            w, h = mod["width"], mod["height"]
            power = mod["power_w"]

            # Map block coordinates to grid indices
            gx0 = int(clamp((x / cw) * gw, 0, gw - 1))
            gy0 = int(clamp((y / ch) * gh, 0, gh - 1))
            gx1 = int(clamp(((x + w) / cw) * gw, 0, gw))
            gy1 = int(clamp(((y + h) / ch) * gh, 0, gh))

            cell_count = max(1, (gx1 - gx0) * (gy1 - gy0))
            power_per_cell = power / cell_count

            grid[gy0:max(gy0+1, gy1), gx0:max(gx0+1, gx1)] += power_per_cell

        # Simple heat diffusion filter
        from scipy.ndimage import gaussian_filter
        temp_map = self.ambient_temp + (grid * self.r_th * 15.0)
        temp_map = gaussian_filter(temp_map, sigma=1.5)

        peak_temp = float(np.max(temp_map))
        return peak_temp, temp_map

def clamp(val, min_v, max_v):
    return max(min_v, min(max_v, val))
