# Thermal-Aware Floorplanning Algorithm Using Hybrid PSO-SA

A thermal-aware VLSI floorplanning framework combining **Particle Swarm Optimization (PSO)** for global spatial exploration and **Simulated Annealing (SA)** for local thermal refinement. Designed to minimize chip area, total wirelength, and peak temperature in modern high-density ICs.

## Project Structure
- `src/pso_sa_floorplanner.py` - Core Hybrid PSO-SA Floorplanning Engine & Thermal Solver
- `src/thermal_model.py` - Grid-based Thermal Dissipation & Hotspot Model
- `tb/test_floorplanner.py` - Verification suite and testbench runner
- `vivado/floorplan_constraints.xdc` - Vivado physical/placement constraints template
- `vivado/run_vivado_flow.tcl` - Tcl script to automate Vivado implementation & thermal report generation
- `config/benchmark_modules.json` - Sample floorplanning benchmark modules with power densities
- `docs/architecture.md` - Technical overview of the hybrid algorithm and thermal modeling

## Key Features
- Hybrid Optimization: Fast global convergence via PSO; local minima escaping via SA
- Multi-Objective Cost Function: $\text{Cost} = \alpha \cdot \text{Area} + \beta \cdot \text{Wirelength} + \gamma \cdot T_{\text{peak}}$
- Thermal Modeling: Compact finite-difference thermal grid solver for temperature distribution
- Vivado & VS Code Integration: Complete Python & Tcl workflow for VLSI placement and thermal reporting

## Quick Start (VS Code / Terminal)
```bash
python src/pso_sa_floorplanner.py --config config/benchmark_modules.json
```

## Vivado Flow
Run the Vivado Tcl script to import floorplan constraints and synthesize/implement:
```bash
vivado -mode batch -source vivado/run_vivado_flow.tcl
```
