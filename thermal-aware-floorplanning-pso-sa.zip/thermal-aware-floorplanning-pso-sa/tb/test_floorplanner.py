import unittest
from src.pso_sa_floorplanner import HybridPSOSA_Floorplanner

class TestThermalFloorplanner(unittest.TestCase):
    def setUp(self):
        self.planner = HybridPSOSA_Floorplanner("config/benchmark_modules.json")

    def test_cost_function(self):
        dummy_placement = {m["name"]: (0.0, 0.0) for m in self.planner.modules}
        cost, area, wl, peak_temp = self.planner.calculate_cost(dummy_placement)
        self.assertGreater(cost, 0)
        self.assertGreater(peak_temp, 0)

    def test_pso_sa_run(self):
        best_placement = self.planner.optimize()
        self.assertEqual(len(best_placement), len(self.planner.modules))

if __name__ == "__main__":
    unittest.main()
