# Hybrid PSO-SA Thermal-Aware Floorplanning Architecture

## Algorithm Overview
1. **Global Exploration (PSO)**:
   - Particles represent floorplan topologies with coordinate vectors for each module.
   - Fast convergence guides search towards low-area and low-wirelength regions.

2. **Local Thermal Refinement (SA)**:
   - Takes the best global solution from PSO.
   - Applies stochastic local moves (e.g., swapping adjacent modules, displacing high-power blocks away from hotspots).
   - Uses Metropolis criterion $P = \exp(-\Delta C / T)$ to escape local minima.

3. **Thermal Model**:
   - Superposition-based finite difference thermal model.
   - Models thermal dissipation across substrate grids to estimate localized peak temperatures ($T_{\text{peak}}$).
